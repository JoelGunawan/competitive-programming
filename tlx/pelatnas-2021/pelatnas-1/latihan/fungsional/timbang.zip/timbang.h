#ifndef __TIMBANG_H__
#define __TIMBANG_H__

#include <vector>

std::vector<int> findOrder(int N, int K);
int compare(int A, int B);

#endif
