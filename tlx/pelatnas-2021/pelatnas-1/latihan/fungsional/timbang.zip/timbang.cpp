#include "timbang.h"
#include <vector>

std::vector<int> findOrder(int N, int K) {

    return std::vector<int>();
}