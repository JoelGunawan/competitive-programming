long long getSum(int N, int A[]) {
  return 0;
}
