#ifndef __SUM_H__
#define __SUM_H__

long long getSum(int N, int A[]);

#endif
