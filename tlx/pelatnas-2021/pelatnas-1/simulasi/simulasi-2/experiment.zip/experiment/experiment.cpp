#include "experiment.h"

#include <vector>

std::vector<long long> get_experiment_results(int N, int M,
                                              std::vector<int> P, std::vector<int> Q,
                                              std::vector<int> L, std::vector<int> R,
                                              std::vector<int> D, std::vector<int> U) {
  std::vector<long long> ans(M, -1);
  return ans;
}
