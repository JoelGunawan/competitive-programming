#include "walk.h"

#include <vector>

long long find_best_walk(int N, long long K, std::vector<int> U, std::vector<int> V, std::vector<int> W) {
  int M = U.size();
  return 42;
}
