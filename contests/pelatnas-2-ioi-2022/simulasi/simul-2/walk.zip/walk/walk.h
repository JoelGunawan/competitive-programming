#ifndef __WALK_H__
#define __WALK_H__

#include <vector>

long long find_best_walk(int N, long long K, std::vector<int> U, std::vector<int> V, std::vector<int> W);

#endif