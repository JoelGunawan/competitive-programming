#ifndef __ADDITION_H__
#define __ADDITION_H__

#include <string>

int count_arrangements(std::string A, std::string B, std::string C);

#endif