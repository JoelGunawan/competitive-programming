#include "addition.h"

#include <string>

int count_arrangements(std::string A, std::string B, std::string C) {
  return 42;
}
