#include "server.h"

#include <vector>

std::vector<int> server(int N, std::vector<int> A, std::vector<int> B, std::vector<int> C) {
  return std::vector<int>(N, 1);
}
