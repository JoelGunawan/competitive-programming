#ifndef __CLIENT_H__
#define __CLIENT_H__

#include <vector>

int get_bit(int p);

int client(int N, std::vector<int> A, std::vector<int> B, int W);

#endif
