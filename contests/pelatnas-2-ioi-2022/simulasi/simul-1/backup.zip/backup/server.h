#ifndef __SERVER_H__
#define __SERVER_H__

#include <vector>

std::vector<int> server(int N, std::vector<int> A, std::vector<int> B, std::vector<int> C);

#endif
