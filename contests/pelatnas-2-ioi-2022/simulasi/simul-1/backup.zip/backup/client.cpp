#include "client.h"

#include <vector>

int client(int N, std::vector<int> A, std::vector<int> B, int W) {
  return 42;
}
