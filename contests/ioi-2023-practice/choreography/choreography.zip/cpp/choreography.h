#include <vector>

void init(int N, std::vector<int> P);

void move_right(int K);

void move_left(int K);

void swap_places();

void move_around();

int get_position(int D);
