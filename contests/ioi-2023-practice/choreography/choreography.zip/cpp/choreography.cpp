#include "choreography.h"
#include <vector>

void init(int N, std::vector<int> P) {
    return;
} 

void move_right(int K) {
    return;
}

void move_left(int K) {
    return;
}

void swap_places() {
    return;
}

void move_around() {
    return;
}

int get_position(int D){
    return 0;
}
