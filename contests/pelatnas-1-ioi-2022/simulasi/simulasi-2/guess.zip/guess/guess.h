#ifndef __GUESS_H__
#define __GUESS_H__

void initialize(int NA, int NB, int NC);

int guess(int K);

int ask(int a, int b, int c);

#endif /* __GUESS_H__ */