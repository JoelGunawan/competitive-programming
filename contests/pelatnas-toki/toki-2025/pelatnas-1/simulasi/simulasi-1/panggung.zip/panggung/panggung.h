#ifndef __panggung_H__
#define __panggung_H__

#include <vector>

int panggung(int N, int M, int Q, std::vector<int> X1, std::vector<int> Y1, std::vector<int> X2, std::vector<int> Y2);

#endif