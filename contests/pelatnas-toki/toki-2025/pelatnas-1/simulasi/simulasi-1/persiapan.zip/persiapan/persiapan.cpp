#include "persiapan.h"

#include <vector>

std::vector<int> persiapan(int N, std::vector<int> X) {
  return std::vector<int>();
}
