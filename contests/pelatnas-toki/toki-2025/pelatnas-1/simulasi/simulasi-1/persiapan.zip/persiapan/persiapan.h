#ifndef __PERSIAPAN_H__
#define __PERSIAPAN_H__

#include <vector>

std::vector<int> persiapan(int N, std::vector<int> X);

#endif
