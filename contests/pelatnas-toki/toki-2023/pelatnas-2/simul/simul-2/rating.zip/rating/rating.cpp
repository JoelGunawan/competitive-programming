#include "rating.h"

#include <vector> 

std::vector<long long> get_ratings(int N, int Q,
    std::vector<int> P, std::vector<int> A, std::vector<int> B, 
    std::vector<int> L, std::vector<int> R
) {
  std::vector<long long> ratings(Q);
  return ratings;
}
