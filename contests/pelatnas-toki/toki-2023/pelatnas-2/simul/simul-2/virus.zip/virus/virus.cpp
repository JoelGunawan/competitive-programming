#include "virus.h"

vector<int> countViruses(int N, int M, int Q, vector<int> u, vector<int> v,
                         vector<int> D, vector<int> C) {
  vector<int> ans;

  for (int i = 0; i < Q; ++i) {
    ans.push_back(69);
  }

  return ans;
}
