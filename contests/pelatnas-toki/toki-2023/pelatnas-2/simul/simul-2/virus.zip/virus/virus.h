#ifndef __VIRUS_H__
#define __VIRUS_H__

#include <vector>
using namespace std;

vector<int> countViruses(int N, int M, int Q, vector<int> u, vector<int> v,
                         vector<int> D, vector<int> C);

#endif
