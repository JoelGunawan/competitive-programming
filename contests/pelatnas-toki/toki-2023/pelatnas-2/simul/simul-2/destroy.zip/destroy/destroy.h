#ifndef __DESTROY_H__
#define __DESTROY_H__

#include <vector>

std::vector<int> destroy(int N, std::vector<int> U, std::vector<int> V);

#endif
