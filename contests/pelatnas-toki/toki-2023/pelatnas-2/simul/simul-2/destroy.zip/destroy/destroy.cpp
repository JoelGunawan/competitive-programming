#include "destroy.h"
#include <vector>

std::vector<int> destroy(int N, std::vector<int> U, std::vector<int> V) {
  std::vector<int> ans(N);
  for (int i = 0; i < N; ++i) {
    ans[i] = i;
  }

  return ans;
}
