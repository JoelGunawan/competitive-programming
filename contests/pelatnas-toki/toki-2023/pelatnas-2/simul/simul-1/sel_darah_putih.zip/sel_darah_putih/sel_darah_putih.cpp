#include "sel_darah_putih.h"

void init(int N, vector<int> u, vector<int> v, int K, vector<int> c) {
  // construct tree
  // TO DO

  // construct assignments
  // TO DO

  return;
}

void reassign(int u, int k) {
  // assign k to u
  // TO DO

  return;
}

int reinforce(int u) {
  int ans = 69;

  // reinforce to node u
  // TO DO

  return ans;
}