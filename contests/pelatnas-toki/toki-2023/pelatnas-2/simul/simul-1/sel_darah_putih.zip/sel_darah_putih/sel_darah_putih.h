#ifndef __SEL_DARAH_PUTIH_H__
#define __SEL_DARAH_PUTIH_H__

#include <vector>
using namespace std;

void init(int N, vector<int> u, vector<int> v, int K, vector<int> c);
void reassign(int u, int k);
int reinforce(int u);

#endif
