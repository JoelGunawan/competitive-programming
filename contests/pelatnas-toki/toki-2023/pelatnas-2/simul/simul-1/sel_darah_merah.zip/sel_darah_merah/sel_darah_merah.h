#ifndef __SEL_DARAH_MERAH_H__
#define __SEL_DARAH_MERAH_H__

#include <vector>
using namespace std;

void initialize(int N, vector<int> L, vector<int> R);
bool configurationExists(int M, vector<int> S);

#endif
