#include "sel_darah_merah.h"

void initialize(int N, vector<int> L, vector<int> R) { return; }

bool configurationExists(int M, vector<int> S) { return true; }
