#include "dengklek.h"

#include <vector>

void giveHint(int N, int M, std::vector<int> A, std::vector<int> B, long long X,
              int T) {

}
