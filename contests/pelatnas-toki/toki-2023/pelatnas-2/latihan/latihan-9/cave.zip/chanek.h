#ifndef __CHANEK_H__
#define __CHANEK_H__

#include <vector>

int move(int D);
long long findNumber(int N, int M, std::vector<int> A, std::vector<int> B,
                     int P, int V, int T);

#endif
