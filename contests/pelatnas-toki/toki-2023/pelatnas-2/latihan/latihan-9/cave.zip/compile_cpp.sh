#!/bin/bash

NAME=cave

/usr/bin/g++ -o $NAME grader.cpp chanek.cpp dengklek.cpp -O2 -lm -std=c++11
