#ifndef __DENGKLEK_H__
#define __DENGKLEK_H__

#include <vector>

void writeMessage(int P, int V);
void giveHint(int N, int M, std::vector<int> A, std::vector<int> B, long long X,
              int T);

#endif
