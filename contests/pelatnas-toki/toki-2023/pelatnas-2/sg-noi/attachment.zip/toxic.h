#include <vector>

void determine_type(int n);
int query_sample(std::vector<int> species);
void answer_type(int x, char c);