g++ -DEVAL -std=gnu++17 -O2 -pipe -static -s -o toxic stub.cpp toxic.cpp
