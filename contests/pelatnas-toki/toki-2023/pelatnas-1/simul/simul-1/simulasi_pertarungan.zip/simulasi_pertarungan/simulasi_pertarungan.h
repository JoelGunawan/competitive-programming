#ifndef __SIMULASI_PERTARUNGAN_H__
#define __SIMULASI_PERTARUNGAN_H__

#include <utility>
using namespace std;

int findMinSimulations(int M, int K);
int findL(bool simulate);

bool fight(int P);

#endif
