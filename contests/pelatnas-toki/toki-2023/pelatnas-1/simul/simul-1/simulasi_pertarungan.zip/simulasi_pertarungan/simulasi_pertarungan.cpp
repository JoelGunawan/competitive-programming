#include "simulasi_pertarungan.h"
#include <utility>
using namespace std;

int findMinSimulations(int M, int K) { return -1; }

int findL(bool simulate) { return -1; }
