#ifndef __LATIHAN_MEMASAK_H__
#define __LATIHAN_MEMASAK_H__

#include <vector>
using namespace std;

vector<long long> findY(int N, int M, int Y, vector<int> r, vector<int> h,
                        vector<int> L, vector<int> R);

#endif
