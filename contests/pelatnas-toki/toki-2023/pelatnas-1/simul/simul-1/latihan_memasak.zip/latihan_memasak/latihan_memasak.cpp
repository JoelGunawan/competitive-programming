#include "latihan_memasak.h"
using namespace std;

vector<long long> findY(int N, int M, int Y, vector<int> r, vector<int> h,
                        vector<int> L, vector<int> R) {
  vector<long long> ret;

  for (int i = 0; i < Y; ++i) {
    ret.push_back(-1);
  }

  return ret;
}
