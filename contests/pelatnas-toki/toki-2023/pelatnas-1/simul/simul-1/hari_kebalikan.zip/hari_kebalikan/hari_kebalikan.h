#ifndef __HARI_KEBALIKAN_H__
#define __HARI_KEBALIKAN_H__

#include <vector>
using namespace std;

vector<int> findA(int N, int Q, vector<int> L, vector<int> R, vector<int> k,
                  vector<int> x);

#endif
