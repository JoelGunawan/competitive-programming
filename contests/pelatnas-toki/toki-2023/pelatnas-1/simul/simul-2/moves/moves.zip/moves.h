#ifndef __MOVES_H__
#define __MOVES_H__

#include <vector>

long long minimum_time(int N, int Q, int A, int B, std::vector<int> X);

#endif
