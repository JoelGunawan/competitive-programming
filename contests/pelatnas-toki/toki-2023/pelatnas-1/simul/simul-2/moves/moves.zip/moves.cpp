#include "moves.h"

#include <vector>

long long minimum_time(int N, int Q, int A, int B, std::vector<int> X) {

  return 0LL;
}
