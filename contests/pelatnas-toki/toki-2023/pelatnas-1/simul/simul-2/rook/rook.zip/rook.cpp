#include "rook.h"

#include <vector>

int minimum_move(int N, std::vector<int> X, std::vector<int> Y,
                 std::vector<int> C) {

  return 0;
}
