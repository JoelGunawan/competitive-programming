#ifndef __ROOK_H__
#define __ROOK_H__

#include <vector>

int minimum_move(int N, std::vector<int> X, std::vector<int> Y,
                 std::vector<int> C);

#endif
