#include "shouter.h"

int give_hint(int N, int x, int y) {
	return 0;
}
