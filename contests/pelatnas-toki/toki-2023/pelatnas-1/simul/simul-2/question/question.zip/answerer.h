#ifndef ANSWERER_H
#define ANSWERER_H

int give_hint(int N, int x, int y);

#endif
