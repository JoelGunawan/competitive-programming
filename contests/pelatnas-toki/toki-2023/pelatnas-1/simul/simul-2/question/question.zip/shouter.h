#ifndef SHOUTER_H
#define SHOUTER_H

bool answer(int N, int q, int h);

#endif
