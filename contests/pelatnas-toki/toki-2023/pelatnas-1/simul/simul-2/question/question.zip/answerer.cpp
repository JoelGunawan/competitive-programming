#include "answerer.h"

bool answer(int N, int q, int h) {
	return true;
}
