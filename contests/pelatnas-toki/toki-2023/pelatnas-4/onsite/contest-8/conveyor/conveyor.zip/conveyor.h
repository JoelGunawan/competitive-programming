#include <vector>

void Solve(int N, std::vector<int> A, std::vector<int> B);

std::vector<int> Query(std::vector<int> x, std::vector<int> y);
void Answer(std::vector<int> a);
