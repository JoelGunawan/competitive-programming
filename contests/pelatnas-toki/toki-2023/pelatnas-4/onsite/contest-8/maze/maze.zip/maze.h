#include <vector>

int minimum_stamps(int R, int C, int N, int Sr, int Sc, int Gr, int Gc,
                   std::vector<std::vector<char>> A);
