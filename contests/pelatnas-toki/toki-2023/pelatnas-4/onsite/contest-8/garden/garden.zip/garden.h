#include <vector>

int minimum_cells(int N, int M, int D, std::vector<int> P, std::vector<int> Q,
                  std::vector<int> R, std::vector<int> S);
