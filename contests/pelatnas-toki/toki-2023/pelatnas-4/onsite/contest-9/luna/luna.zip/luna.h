#include <vector>

long long minimum_actions(int N, std::vector<int> A);
