#include "sopsug.h"

#include <vector>

void build_tubes(int N, int M, int K, std::vector<int> A, std::vector<int> B,
                 std::vector<int> C, std::vector<int> D) {

}
