#include "box.h"

#include <utility>

std::pair<int, int> find_box(int H, int W) {
  return std::make_pair(0, 0);  
}
