#include <string>
#include <utility>

std::pair<int, int> find_box(int H, int W);
std::pair<int, int> move_robot(std::string s);
