#ifdef __cplusplus
extern "C" {
#endif

int get_n();
int is_clockwise(int a, int b, int c);
void give_answer(int s);

#ifdef __cplusplus
}
#endif
