#include "guess.h"

void guess(int n) {
  ask(1, 2, 3);
  answer(1, 1);
  answer(2, 2);
  answer(3, 3);
}
