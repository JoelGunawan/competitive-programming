int ask(int x, int y, int z);

void answer(int x, int v);

void guess(int n);
