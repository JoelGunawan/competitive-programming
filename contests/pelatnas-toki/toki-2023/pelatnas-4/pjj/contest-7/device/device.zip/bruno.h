#ifndef __BRUNO_H__
#define __BRUNO_H__

long long Bruno( int N, int A[] );

#endif