#!/bin/bash

NAME=device

/usr/bin/g++ -o $NAME grader.cpp anna.cpp bruno.cpp -O2 -lm -std=c++11