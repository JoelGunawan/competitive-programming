#include "anna.h"

void Anna( int N, long long X, int K, int P[] ){
  for( int i = 0; i < N; i++ ){
    Set( i, 0 );
  }
}
