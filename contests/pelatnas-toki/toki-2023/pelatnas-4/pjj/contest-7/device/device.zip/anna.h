#ifndef __ANNA_H__
#define __ANNA_H__

void Anna( int N, long long X, int K, int P[] );
void Set( int pos, int bit );

#endif