#include <vector>

std::vector<long long> count_subpaths(int N, int K, int Q, std::vector<int> U,
                                      std::vector<int> V, std::vector<char> C,
                                      std::vector<int> X, std::vector<int> Y);
