#include <vector>

int count_writings(int N, int K, std::vector<int> P, std::vector<int> A);
