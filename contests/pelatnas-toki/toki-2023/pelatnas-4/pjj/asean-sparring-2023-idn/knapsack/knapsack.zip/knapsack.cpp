#include "knapsack.h"

#include <vector>

long long find_maximum(int N, long long T, std::vector<int> W, std::vector<int> V) {
  return 0;
}
