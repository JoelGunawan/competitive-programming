#include "game.h"

#include <vector>

void init(std::vector<int> B) {
  int N = B.size();
  return;
}

long long modify(int i, int x) {
  long long ret = 42;

  return ret;
}
