#ifndef __GAME_H__
#define __GAME_H__

#include <vector>

void init(std::vector<int> B);

long long modify(int i, int x);

#endif
