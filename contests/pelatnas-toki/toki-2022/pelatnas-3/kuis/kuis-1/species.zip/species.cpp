#include "species.h"

#include <string>
#include <vector>

void init(std::string G, std::vector<int> P) {
  int N = G.size();
}

int count_species(int S, int T) {
  return 42;
}
