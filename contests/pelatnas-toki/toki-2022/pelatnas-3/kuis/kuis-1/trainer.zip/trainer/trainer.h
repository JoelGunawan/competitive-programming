#ifndef __TRAINER_H__
#define __TRAINER_H__

#include <vector>

long long minimize_penalty(std::vector<int> L, std::vector<int> R, std::vector<std::vector<int>> A);

#endif