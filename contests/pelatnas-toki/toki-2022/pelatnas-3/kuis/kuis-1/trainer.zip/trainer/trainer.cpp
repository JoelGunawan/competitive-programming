#include "trainer.h"

#include <vector>

long long minimize_penalty(std::vector<int> L, std::vector<int> R, std::vector<std::vector<int>> A) {
  int K = L.size();
  int M = A.size();
  int N = A[0].size() / 2;
  return 42;
}
