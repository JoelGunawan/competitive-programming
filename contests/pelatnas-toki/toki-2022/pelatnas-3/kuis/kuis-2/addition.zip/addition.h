#ifndef __ADDITION_H__
#define __ADDITION_H__

#include <vector>
#include <string>

int count_addition(std::vector<std::string> S, int X);

#endif