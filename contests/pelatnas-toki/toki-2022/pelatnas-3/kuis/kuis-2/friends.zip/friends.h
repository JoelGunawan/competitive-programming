#ifndef __FRIENDS_H__
#define __FRIENDS_H__

#include <vector>

int pairing_sum(std::vector<int> U, std::vector<int> V, std::vector<int> W, std::vector<int> H);

#endif