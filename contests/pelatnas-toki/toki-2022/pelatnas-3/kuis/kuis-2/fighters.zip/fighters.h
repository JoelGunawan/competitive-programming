#ifndef __FIGHTERS_H__
#define __FIGHTERS_H__

#include <vector>

long long minimum_strength(std::vector<int> A, std::vector<int> B);

void fight(std::vector<int> P);

#endif
