#include "fighters.h"

#include <vector>

long long minimum_strength(std::vector<int> A, std::vector<int> B) {
  int N = A.size();
  int M = B.size();
  fight({1, 5, 3});
  fight({5, 4, 0});
  fight({2, 6, 0});
  return 8;
}
