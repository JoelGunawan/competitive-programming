#include <vector>
#include <string>

std::string process(std::vector<std::vector<std::string> > a,int i,int j,int k,int n);
