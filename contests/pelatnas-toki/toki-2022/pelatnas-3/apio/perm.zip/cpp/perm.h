#include <vector>

std::vector<int> construct_permutation(long long k);
