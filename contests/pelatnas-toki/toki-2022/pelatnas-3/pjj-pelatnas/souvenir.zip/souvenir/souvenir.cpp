#include "souvenir.h"

#include <vector>

long long buy_souvenir(std::vector<int> A, std::vector<int> X, std::vector<int> B, std::vector<int> Y) {
  int N = A.size();
  int M = B.size();
  return 42;
}
