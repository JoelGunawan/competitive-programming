#ifndef __SOUVENIR_H__
#define __SOUVENIR_H__

#include <vector>

long long buy_souvenir(std::vector<int> A, std::vector<int> X, std::vector<int> B, std::vector<int> Y);

#endif