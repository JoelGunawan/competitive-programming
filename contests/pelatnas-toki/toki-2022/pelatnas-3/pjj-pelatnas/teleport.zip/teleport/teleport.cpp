#include "teleport.h"

#include <vector>

std::vector<int> explore(int N, int X) {
  std::vector<int> ans(N, 0);
  ans[0] = N;

  use_teleporter(0);
  change_news_channel(1);
  int c = ask_news_channel();
  int d = ask_count_teleporters();
  int e = ask_last_teleporter();

  return ans;
}
