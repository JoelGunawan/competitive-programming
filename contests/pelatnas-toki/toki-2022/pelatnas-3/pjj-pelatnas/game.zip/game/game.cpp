#include "game.h"

#include <vector>

std::vector<int> play_game(int N) {
  return std::vector<int>(N, ask_minimum_xor(42));
}
