#ifndef __GAME_H__
#define __GAME_H__

#include <vector>

std::vector<int> play_game(int N);

int ask_minimum_xor(int x);

#endif