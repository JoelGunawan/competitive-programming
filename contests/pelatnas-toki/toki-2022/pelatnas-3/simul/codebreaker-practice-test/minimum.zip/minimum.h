using namespace std;

int findMin(int N, int A[]);
