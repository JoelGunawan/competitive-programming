#include "minimum.h"
using namespace std;

int findMin(int N, int A[]) {
    return 0;
}
