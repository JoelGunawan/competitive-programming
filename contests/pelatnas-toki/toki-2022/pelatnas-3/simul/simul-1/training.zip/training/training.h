#ifndef __TRAINING_H__
#define __TRAINING_H__

#include <vector>

std::vector<int> find_training_routes(int N, std::vector<int> A, std::vector<int> B, std::vector<int> C);

#endif