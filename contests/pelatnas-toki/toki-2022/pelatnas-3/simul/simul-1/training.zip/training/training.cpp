#include "training.h"

#include <vector>

std::vector<int> find_training_routes(int N, std::vector<int> A, std::vector<int> B, std::vector<int> C) {
  int M = A.size();
  return std::vector<int>(N, 42);
}
