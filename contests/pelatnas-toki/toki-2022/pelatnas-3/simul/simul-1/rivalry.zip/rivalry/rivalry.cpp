#include "rivalry.h"

#include <vector>

std::vector<long long> find_final_scores(int N, std::vector<int> A, std::vector<int> B) {
  int M = A.size();
  return std::vector<long long>(N, 42);
}
