#ifndef __RIVALRY_H__
#define __RIVALRY_H__

#include <vector>

std::vector<long long> find_final_scores(int N, std::vector<int> A, std::vector<int> B);

#endif