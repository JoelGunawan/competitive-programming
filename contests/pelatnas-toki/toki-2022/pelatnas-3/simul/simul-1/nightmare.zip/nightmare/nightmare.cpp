#include "nightmare.h"

#include <vector>

int count_sequences(std::vector<int> A) {
  int N = A.size();
  return 42;
}
