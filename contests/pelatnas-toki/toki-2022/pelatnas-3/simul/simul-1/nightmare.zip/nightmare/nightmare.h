#ifndef __NIGHTMARE_H__
#define __NIGHTMARE_H__

#include <vector>

int count_sequences(std::vector<int> A);

#endif