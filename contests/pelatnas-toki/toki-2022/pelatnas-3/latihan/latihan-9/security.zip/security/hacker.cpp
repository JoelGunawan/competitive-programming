#include "hacker.h"

#include <vector>

std::vector<int> hacker(std::vector<int> A, std::vector<int> B, std::vector<int> C) {
  int N = A.size();
  int M = B.size();
  return {2, 3};
}
