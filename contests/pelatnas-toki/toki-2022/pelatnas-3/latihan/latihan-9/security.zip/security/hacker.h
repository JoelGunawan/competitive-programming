#ifndef __HACKER_H__
#define __HACKER_H__

#include <vector>

std::vector<int> hacker(std::vector<int> A, std::vector<int> B, std::vector<int> L);

#endif