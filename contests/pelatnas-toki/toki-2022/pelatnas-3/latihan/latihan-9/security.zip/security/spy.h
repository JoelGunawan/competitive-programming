#ifndef __SPY_H__
#define __SPY_H__

#include <vector>

std::vector<int> spy(std::vector<int> A, std::vector<int> B, std::vector<int> C);

#endif