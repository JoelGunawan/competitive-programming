#ifndef __PEKERJAAN_H__
#define __PEKERJAAN_H__

#include <vector>

void init(std::vector<int> C, std::vector<int> U, std::vector<int> V);

long long kerugian_minimum(std::vector<int> P);

#endif
