#include "pekerjaan.h"

#include <vector>

void init(std::vector<int> C, std::vector<int> U, std::vector<int> V) {
  int N = C.size();
}

long long kerugian_minimum(std::vector<int> P) {
  return 42;
}
