#include "art.h"
#include <vector>

std::vector<int> calculate_steps(int N, std::vector<int> A) {
  return {};
}
