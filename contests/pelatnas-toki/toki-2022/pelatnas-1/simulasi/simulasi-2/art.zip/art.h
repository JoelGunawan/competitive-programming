#ifndef __ART_H__
#define __ART_H__

#include <vector>

std::vector<int> calculate_steps(int N, std::vector<int> A);

#endif
