#include <vector>

long long min_leftover(int N, std::vector<int> A);
