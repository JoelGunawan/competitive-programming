#include "zebra.h"

#include <vector>

int find_root(int N, std::vector<int> U, std::vector<int> V) {
  is_zebra({1, 4, 5});
  is_zebra({0, 3, 1, 2});
  is_zebra({0, 0, 5, 5});
  is_zebra({3});
  return 3;
}
