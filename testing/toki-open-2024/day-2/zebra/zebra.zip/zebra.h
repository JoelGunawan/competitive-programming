#include <vector>

int find_root(int N, std::vector<int> U, std::vector<int> V);
int is_zebra(std::vector<int> edges);
