#include <vector>

void init(int N, int M, std::vector<int> A);
void toggle(int R);
long long query(int S, int T);
