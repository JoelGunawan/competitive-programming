#include "secret.h"

#include <vector>

void init(int N, int M, std::vector<int> A) {
  return;
}

void toggle(int R) {
  return;
}

long long query(int S, int T) {
  return 0;
}
