#include <vector>

std::pair<long long, int> purwokerto(int N, int M, std::vector<int> T);
