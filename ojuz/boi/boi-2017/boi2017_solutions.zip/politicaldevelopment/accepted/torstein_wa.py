#!/usr/bin/env python3
import sys

def poldev():
    # Step 0: Read input
    n, k = map(int, sys.stdin.readline().split())
    return k
    
print(poldev())