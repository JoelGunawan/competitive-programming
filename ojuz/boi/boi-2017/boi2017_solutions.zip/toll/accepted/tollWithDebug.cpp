#include<stdio.h>
#include<vector>
#include<iostream>
#define llint long long 

using namespace std;

const llint bigVal = ((long long) 100000)*((long long) 100001);
int K;

// shortest path matrix
struct spm {
	vector<vector<llint> > M;
	
	spm () {}
	
	spm (int dim) {
		M = vector<vector<llint> > (dim, vector<llint> (dim, bigVal));
		for(int i = 0; i < dim; ++i) M[i][i] = 0;
	}
	
	spm(int dim, llint initVal) {M = vector<vector<llint> > (dim, vector<llint> (dim, initVal));}
	
	inline int dim() {return M.size();}
	
	void printMe() {
		for(int j = 0; j < dim(); ++j) {
			for(int p = 0; p < dim(); ++p) {
				llint vv = M[j][p];
				vv = vv >= bigVal ? -1 : vv;
				cout << vv << " ";
			}
			cout << endl;
		}
	}
	
};

// overload + to (min,+) product for spm's.
spm operator + (spm L, spm R) {
	int dim = L.dim();
	spm ans(dim, 0);
	for(int i = 0; i < dim; ++i) {
		for(int j = 0; j < dim; ++j) {
			llint cur = L.M[i][0] + R.M[0][j];
			for(int k = 1; k < dim; ++k) {
				llint newVal = L.M[i][k] + R.M[k][j];
				cur = cur < newVal ? cur : newVal;
			}
			ans.M[i][j] = cur;
		}
	}
	return ans;
}

// binary segment tree for spms without update capability. 
struct bst {
	vector<spm> a;
	int N;
	int offs;
	
	bst(vector<spm> initArray) {
		int n = initArray.size();
		N = 2;
		while(N < 2*n+4) N *= 2;
		offs = N/2 + 1;
		a = vector<spm> (N, spm(K, bigVal));
		for(int i = 0; i < n; ++i) a[i+offs] = initArray[i];
		for(int i = offs-2; i > 0; --i) a[i] = a[2*i] + a[(2*i)+1];
	}
	
	spm sum(int i, int j) {
		int L = i + offs - 1;
		int R = j + offs + 1;
		spm Lans(K);
		spm Rans(K);
		while(true) {
			bool Lright = L%2 == 0;
			bool Rleft = R%2 == 1;
			L /= 2; 
			R /= 2;
			if(L==R) break;
			if(Lright) Lans = Lans + a[2*L+1];
			if(Rleft) Rans = a[2*R] + Rans;
		}
		return Lans + Rans;
	}
	
	void printMe() {
		cout << "printing bst" << endl;
		for(int i = 1; i < N; ++i) {
			cout << i << endl;
			a[i].printMe();
		}
		cout << "done bst"<< endl << endl;;
	}
	
};

int main() {
	
	int N,M,O;
		
	// read input
	scanf("%d%d%d%d",&K,&N,&M,&O);
		
	vector<spm> initArray;
	for(int i = 0; i < N/K; ++i) initArray.push_back(spm(K,bigVal));
	
	//vector<spm> initArray(N/K+1, spm(K, bigVal));
	for(int i = 0; i < M; ++i) {
		int a,b,t;
		scanf("%d%d%d",&a,&b,&t);
		initArray[a/K].M[a%K][b%K] = t;
	}

	// make bst
	bst T(initArray);
	
	// answer queries
	for(int i = 0; i < O; ++i) {
		int a,b;
		scanf("%d%d",&a,&b);
		spm ans = T.sum(a/K, b/K-1);
		printf("%lld\n", (ans.M[a%K][b%K] < bigVal ? ans.M[a%K][b%K] : -1));
	}
	
	return 0;
}