#include "paint_c.h"

void solve_puzzle(int n, char* s, int k, int* c, char* result) {
    result[0] = 'X';
}
