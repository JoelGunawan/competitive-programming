public class paint {

    public String solve_puzzle(String s, int[] c) {
        return "";
    }
    
}
