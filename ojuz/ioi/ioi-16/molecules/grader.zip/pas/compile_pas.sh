#!/bin/bash

problem=molecules

fpc -XS -O2 -o$problem grader.pas
