#include "molecules.h"

std::vector<int> find_subset(int l, int u, std::vector<int> w) {
    return std::vector<int>(0);
}
