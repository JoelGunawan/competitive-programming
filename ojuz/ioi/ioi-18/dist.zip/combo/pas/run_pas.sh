#!/bin/bash

TASK=combo

./${TASK}
