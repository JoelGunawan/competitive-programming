public class horses {
	public int init(int N, int[] X, int[] Y) {
		return 0;
	}
	public int updateX(int pos, int val) {
		return 0;
	}
	public int updateY(int pos, int val) {
		return 0;
	}
}
