#include "horses.h"

int init(int N, int X[], int Y[]) {
	return 0;
}

int updateX(int pos, int val) {	
	return 0;
}

int updateY(int pos, int val) {
	return 0;
}
