#!/bin/bash

problem=boxes

java -jar -Xmx1500M -Xms1400M -Xss64M $problem.jar
