#include "boxes.h"

long long delivery(int N, int K, int L, int p[]) {
    return 0;
}
