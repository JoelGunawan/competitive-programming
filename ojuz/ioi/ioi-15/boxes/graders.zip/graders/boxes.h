#ifndef boxes_h
#define boxes_h

long long delivery(int N, int K, int L, int p[]);

#endif
