public class boxes {
    long delivery(int N, int K, int L, int p[]) {
        return 0;
    }
}
