#include "cave.h"

void exploreCave(int N) {
    /* ... */
}
