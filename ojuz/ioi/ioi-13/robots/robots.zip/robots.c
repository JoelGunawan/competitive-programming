#include "robots.h"

int putaway(int A, int B, int T, int X[], int Y[], int W[], int S[]) {
    return 42;
}
