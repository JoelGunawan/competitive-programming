#include <vector>

int construct(std::vector<std::vector<int>> p);
void build(std::vector<std::vector<int>> b);
