public class supertrees {
	int construct(int[][] p) {
		int n = p.length;
		int[][] answer = new int[n][n];
		grader.build(answer);
		return 1;
	}
}
