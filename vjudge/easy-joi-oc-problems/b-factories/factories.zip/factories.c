#include "factories.h"

void Init(int N, int A[], int B[], int D[]) {
}

long long Query(int S, int X[], int T, int Y[]) {
  return 0;
}
