#ifndef FACTORIES_H_
#define FACTORIES_H_

void Init(int N, int A[], int B[], int D[]);
long long Query(int S, int X[], int T, int Y[]);

#endif  /* FACTORIES_H_ */
